Description: This code isn't too different from A. It just has some additional properties
added onto the Block class.

Additional Note:
Coded added on from A

If code doesn't output, copy code into a project with no package like a scratch pad project for instance, 
and try again. That typically works for me. 
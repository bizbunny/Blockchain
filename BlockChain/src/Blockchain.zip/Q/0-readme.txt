This file is the same as the Blockchain.java file outside of this folder. It's heavily based on Project O

Notes:
If code doesn't output, copy code into a project with no package like a scratch pad project for instance, 
and try again. That typically works for me. 
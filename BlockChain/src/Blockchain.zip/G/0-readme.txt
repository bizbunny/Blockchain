Description:
Stand alone code that takes in string as input. Will display encryption with public and private keys and decryption with public and private keys. 
Uses symmetric encryption. Will also convert public key to string then write it to JSON.

The code will write to JSON. It just won't read it in. For reading JSON in, we fake it here.

Additional Notes:
If code doesn't output, copy code into a project with no package like a scratch pad project for instance, 
and try again. That typically works for me. 
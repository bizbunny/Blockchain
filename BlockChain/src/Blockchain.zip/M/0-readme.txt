Description: stanalone program that uses Priority Queue to manipulate the blockchain. Uses fake dummy data.

Notes:
If code doesn't output, copy code into a project with no package like a scratch pad project for instance, 
and try again. That typically works for me. 
Description: The code does similar stuff to A2 except now we translate to JSON and write it to disk.

Additional Notes:
Code from A2 added onto / altered to make B

If code doesn't output, copy code into a project with no package like a scratch pad project for instance, 
and try again. That typically works for me. 
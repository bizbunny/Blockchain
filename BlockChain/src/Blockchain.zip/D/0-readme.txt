Description: This code needs an argument to pass. 0, 1, 2 should work. To do multiple arguments at once, best run ProcessMaker in separate terminal windows using
different numbers as arguments as suggested. Each window should then see Hello from Process [number agument].

Additional Notes:
Got code from C and altered and rename some stuff to fit what I was supposed to do and make D

If code doesn't output, copy code into a project with no package like a scratch pad project for instance, 
and try again. That typically works for me. 
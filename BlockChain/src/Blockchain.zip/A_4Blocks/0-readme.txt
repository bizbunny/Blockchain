Description: The program makes blocks with some properties and makes four of them starting 
with a dummy block with 0 as its parameter for previous hash. All properties of each block
are printed out for viewing purposes.

Additional Notes:
Verifying a block here involves checking if each character of a hash is not 0. Super easy puzzle.
It's more of a dummy verify method than anything else.

The random seed for all is 0;
Basic 4 blocks with only 1 process running.

If code doesn't output, copy code into a project with no package like a scratch pad project for instance, 
and try again. That typically works for me. 
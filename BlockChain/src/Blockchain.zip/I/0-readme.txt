Description: standalone problem drawing heavily from H with some differences. 
This code was used to make I

Additional Notes:
If code doesn't output, copy code into a project with no package like a scratch pad project for instance, 
and try again. That typically works for me. 
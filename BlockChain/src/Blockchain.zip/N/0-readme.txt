Description: code is identical to M since relatively speaking, they do the same thing. the blocks get multicasted, so all 3 processes end up with 12.
Stanalone program that uses Priority Queue to manipulate the blockchain. Uses fake dummy data.

Additional Notes:
If code doesn't output, copy code into a project with no package like a scratch pad project for instance, 
and try again. That typically works for me. 
Description: Additional sleep statement was added.

Additional Notes:
Got code from D and altered / added on to make E

If code doesn't output, copy code into a project with no package like a scratch pad project for instance, 
and try again. That typically works for me. 
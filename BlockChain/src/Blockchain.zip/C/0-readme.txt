Description: This code does similar stuff to B. Now however, we don't just convert to JSON
and write to disk. Instead we also read the JSON back in and convert it back to java
objects.

Additional Note:
Code from B that was added onto / altered to make C

If code doesn't output, copy code into a project with no package like a scratch pad project for instance, 
and try again. That typically works for me. 
Description: takes in files from sample text files and builds blocks using them
Multicasting then happens to send 4 blocks each to separate processes

Notes:
If code doesn't output, copy code into a project with no package like a scratch pad project for instance, 
and try again. That typically works for me. 
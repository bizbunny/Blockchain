Description: Similar code to what we had in N and other previous programs, except for the face that we've added producer consumer logic into
the picture.

Notes:
If code doesn't output, copy code into a project with no package like a scratch pad project for instance, 
and try again. That typically works for me. 